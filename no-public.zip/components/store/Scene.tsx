'use client'
import { Canvas } from '@react-three/fiber'
import { Environment } from '@react-three/drei'
import * as THREE from 'three'
import { Suspense } from 'react'
import { useStoreConfig } from './hooks/useStoreConfig'
import { ModelLoader } from './ModelLoader'
import { usePhysics } from './PhysicsSystem'
import { usePlayerController } from './PlayerController'
import { VirtualJoystick } from './Joystick'
import { usePOVCamera } from './POVCamera'
import { ShadowSystem } from './ShadowSystem'
import { ReflectiveFloor } from './ReflectiveFloor'
import { PostProcessing } from './PostProcessing'
import { useState, useEffect, useCallback } from 'react'
import ProductInteraction, { type ProductData } from './ProductInteraction'
import ProductPopup from './ProductPopup'
import { LoadingScreen } from './LoadingScreen'
import { ModelsLoadingIndicator } from './ModelsLoadingIndicator'

function ErrorScreen({ message }: { message: string }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black text-red-500">
      <div className="text-center">
        <div className="text-xl mb-2">Error</div>
        <div>{message}</div>
      </div>
    </div>
  )
}

function PhysicsManager({ onSetJoystickInput }: { onSetJoystickInput: (callback: (x: number, y: number) => void) => void }) {
  const physics = usePhysics()
  const { setJoystickInput } = usePlayerController(physics)
  usePOVCamera()

  useEffect(() => {
    onSetJoystickInput(() => (x: number, y: number) => setJoystickInput(x, y))
  }, [setJoystickInput, onSetJoystickInput])

  return null
}

export default function Scene() {
  const { config, loading, error } = useStoreConfig()
  const [joystickCallback, setJoystickCallback] = useState<((x: number, y: number) => void) | null>(null)
  const [showClickHint, setShowClickHint] = useState(true)
  const [modelsLoaded, setModelsLoaded] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<ProductData | null>(null)

  const handleModelsLoaded = useCallback(() => {
   
    setModelsLoaded(true)
  }, [])

  useEffect(() => {
    const hideHint = () => setShowClickHint(false)
    window.addEventListener('mousedown', hideHint, { once: true })
    return () => window.removeEventListener('mousedown', hideHint)
  }, [])

  if (loading) return <LoadingScreen />
  if (error) return <ErrorScreen message={error} />
  if (!config) return <ErrorScreen message="No store config found" />

  return (
    <>
      <Canvas
        style={{ touchAction: 'none' }}
        shadows
        dpr={[1, 2]}
        gl={{
          antialias: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.0,
        }}
        camera={{ position: [0, 1.6, 5], fov: 60, near: 0.1, far: 200 }}
      >
        
      {/* Dark background */}
      {/* <color attach="background" args={['#1a1a1a']} /> */}

      {/* HDRI lighting */}
      <Suspense fallback={null}>
        <Environment
          files="/hdr/studio_small_09_1k.hdr"
          background={false}
          environmentIntensity={1.0}
          resolution={256}
        />
      </Suspense>

      {/* Key light (sun) */}
      <directionalLight
        position={[10, 5, 5]}
        intensity={2.8}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.025}
      >
                {/* Param	Value	Effect
        left/right	±20	Shadow width: 40 units total
        top/bottom	±20	Shadow depth: 40 units total
        near	0.1	Closest shadow distance from light
        far	60	Farthest shadow distance from light */}
          {/* In your scene: Everything within ±20 units horizontally and up to 60 units deep will cast shadows. Objects outside this area won't cast shadows.  */}
        <orthographicCamera
          attach="shadow-camera"
          args={[-20, 20, 20, -20, 0.1, 60]}
        />
      </directionalLight>

      {/* Fill light */}
      {/* <directionalLight position={[-7, 4, -5]} intensity={0.5} color="#cdd6ff" /> */}

      {/* PCSS Soft Shadows */}
      <ShadowSystem size={25} samples={17} focus={0} />

      {/* Load models from config */}
      <Suspense fallback={null}>
        <ModelLoader files={config.files} onModelsLoaded={handleModelsLoaded} />
      </Suspense>

      {/* Physics system (Octree + Capsule + Gravity) - only after models loaded */}
      {modelsLoaded && <PhysicsManager onSetJoystickInput={setJoystickCallback} />}

      {/* Product click interaction */}
      {modelsLoaded && <ProductInteraction onProductClick={setSelectedProduct} />}

      {/* Reflective Floor (Phase 9) */}
      <ReflectiveFloor size={60} mixStrength={.5} blur={1} roughness={.82} />

      {/* Post-Processing (Phase 10) */}
      <PostProcessing />
      </Canvas>

      {/* Loading indicator while models load */}
      {!modelsLoaded && <ModelsLoadingIndicator />}

      {/* Virtual joystick for mobile - only after models loaded */}
      {modelsLoaded && joystickCallback && <VirtualJoystick onMove={joystickCallback} />}

      {/* Drag to look around hint */}
      {modelsLoaded && showClickHint && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-black/70 text-white px-6 py-3 rounded-lg text-sm">
            Drag to look around • WASD to move
          </div>
        </div>
      )}

      {/* Product popup */}
      <ProductPopup product={selectedProduct} onClose={() => setSelectedProduct(null)} />
    </>
  )
}
